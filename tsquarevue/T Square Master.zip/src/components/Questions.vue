<template>
<div class="container my-5">
	<h1 class="text-left">General Frequently Asked Questions</h1>
	<div class="accordion" id="accordionExample">
		<!-- Item 1-->
		<div class="accordion-item">
			<h2 class="accordion-header" id="headingOne">
				<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
				How do I sign up for an account?
				</button>
			</h2>
			<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
				<div class="accordion-body text-left">
					<p> <b> 1. Sign up via Email </b></p>
					<p> To create an account using your email address:</p>
					<ol>
						<li>Select 'Sign in with email'</li>
						<li>Enter First & Last name</li>
						<li>Enter your choice of Password</li>
						<li>Tap on 'Save' and you're ready!</li>
						<li>Your T Square account will be created immediately and you’ll be logged in to your new brand new account!</li>
					</ol>
					<br>
					<p> <b> 2. Sign up via Google Mail </b></p>
					<p> To create an account using your email address:</p>
					<ol>
						<li>Select 'Sign in with Google'</li>
						<li>Sign in to your existing Google account</li>
						<li>Your T Square account will be created immediately and you’ll be logged in to your new brand new account!</li>
					</ol>
				</div>
			</div>
		</div>
		<!-- Item 2 -->
		<div class="accordion-item">
			<h2 class="accordion-header" id="headingTwo">
				<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
				[Account Security] How do I change/update my email account?
				</button>
			</h2>
			<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
				<div class="accordion-body text-left">
					<p>You can change your email account by following these steps:</p>
					<ol>
						<li>Go to Settings.</li>
						<li>Click Profile.</li>
						<li>Click "Change email".</li>
						<li>Enter your password for verification.</li>
						<li>Enter your new email account.</li>
						<li>Tap on Continue to complete the process.</li>
					</ol>
				</div>
			</div>
		</div>

		<!-- Item 3 -->
		<div class="accordion-item">
			<h2 class="accordion-header" id="headingThree">
				<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
				[My Account] Why did I not receive my verification email?
				</button>
			</h2>
			<div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
				<div class="accordion-body text-left">
					<p>If you do not receive the email, please check your spam and junk mail.</p>
					<p>In the event that no email can be found, you can request another verification email from your profile page setting or drop us an email at <b>contact@tsquare.com.sg</b></p>
				</div>
			</div>
		</div>

		<!-- Item 4 -->
		<div class="accordion-item">
			<h2 class="accordion-header" id="headingFour">
				<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
				How do I contact the Support Team?
				</button>
			</h2>
			<div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
				<div class="accordion-body text-left">
					<p>Solving problems is a Core Value here at T Square! We want all our users to get the help they need quickly and efficiently. </p>
					<p>Do drop us an email at <b><a href="mailto:contact@tsquare.com.sg">contact@tsquare.com.sg</a></b> and our customer service will get back to as soon as possible</p>
				</div>
			</div>
		</div>
	</div>
</div>  
</template>

<script>
export default {

}
</script>

<style>

</style>
